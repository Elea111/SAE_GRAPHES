Membres de l'équipe :
Sathush
Jordan
Léona
Éléa 
Zhongqi
Groupe 111


Synthèse :
Nous avons codé les classes GrapheLAdj.java, GrapheLArcs.java et Arc.java, et modifié certaines méthodes que nous n'avons pas clairement compris de la classe GrapheMAdj.java.

L'algorithme de Dijkstra passe pour les graphes suivants :
Dorogovtsev-Mendes jusqu'à 10000 sommets
Barabasi-Albert jusqu'à 10000 sommets
Full-Connected jusqu'à 5001 sommets sans l'utilisation de la classe GrapheLArcs
