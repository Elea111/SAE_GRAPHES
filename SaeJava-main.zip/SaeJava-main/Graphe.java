package graphe;


public abstract class Graphe implements IGraphe {
	@Override
	public String toString() {
		return toAString();
	}
}
